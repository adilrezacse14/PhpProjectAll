<!DOCTYPE html>
<html lang="en">
<head>
  <title>Management Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bs4/bootstrap.min.css">
  <script src="bs4/jquery.min.js"></script>
  <script src="bs4/popper.min.js"></script>
  <script src="bs4/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron text-center">
  <h1>Welcome to the Coaching management</h1>
  <p>This is the demo of some operation for managing the students of a coaching</p> 
</div>
  
<div class="container">
`	<div class="row">
		<div class="col-md-4">
			
		</div>
		<div class="col-md-4">
			
		</div>
		<div class="col-md-4">
			
		</div>

	</div>
</div>

</body>
</html>
