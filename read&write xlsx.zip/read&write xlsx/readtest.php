<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Hello test</title>
</head>
<body>
	
	
	<?php
		
		require_once "Classes/PHPExcel.php";
		$tmpvar = 'hello.xlsx';
		
		// $xlreader=PHPExcel_IOFactory::createReaderForFile($tmpvar);
		// $xlob=$xlreader->load($tmpvar);
		
		$xlob=PHPExcel_IOFactory::load($tmpvar);
		
		#$worksheet=$xlob->getActiveSheet(); this will give the active sheet, one sheet contain a lot of sheet
		#$worksheet=$xlob->getSheet(0);
		$worksheet=$xlob->getSheet(0);
		$lastrow=$worksheet->getHighestRow();//return a integer value which define as a last element line no
		echo $lastrow;
		echo "<br />";
		
		for($row=1;$row<=$lastrow; $row++)
		{
			echo $worksheet->getCell('A'.$row)->getValue();
			echo "&nbsp;";
			echo "&nbsp;";
			echo "&nbsp;";
			echo "&nbsp;";
			echo $worksheet->getCell('B'.$row)->getValue();
			echo "<br />";
		}
		
	
	?>
	
	
	
</body>
</html>