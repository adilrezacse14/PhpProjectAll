<?php
	$connection=$cntt=mysqli_connect("localhost","root","","studentmanagement");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Management Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bs4/bootstrap.min.css">
  <script src="bs4/jquery.min.js"></script>
  <script src="bs4/popper.min.js"></script>
  <script src="bs4/bootstrap.min.js"></script>
  <link rel="stylesheet" href="common.css" />
</head>
<body>

<div class="jumbotron text-center headd" style="height:180px;">
  <h1>Welcome to the Coaching management</h1>
  <p>This is the demo of some operation for managing the students of a coaching</p> 
</div>

<div class="container">

<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-6 details">
	
		<?php
			$sid=$_GET['sid'];
			$sql="select * from studentinfo where id='$sid'";
			$result=mysqli_query($connection, $sql);
			$row=mysqli_fetch_array($result);
			$fname=$row['fname'];
			$lname=$row['lname'];
			$fullname=$fname." ".$lname;
			$collegename=$row['collegename'];
			$smobile=$row['smobile'];
			$Gmobile=$row['gmobile'];
			$battch=$row['battch'];
			$broll=$row['broll'];
			$image=$row['image'];
		?>
		<div class="container dkp">
			<div class="dkpleft">
				<img src="studentimage/<?php echo $image;?>" alt="user Imge" style="height:200px;width:160px;border-radius:20px;"/>
			</div>
			
			<div class="dkpright">
				<pre style="color:white;">        Name:  <?php echo $fullname?></pre>
				<pre style="color:white;"> CollegeName:  <?php echo $collegename?></pre>
				<pre style="color:white;"> Student_Mob:  <?php echo $smobile?></pre>
				<pre style="color:white;"> Gardian_Mob:  <?php echo $Gmobile?></pre>
				<pre style="color:white;">       Bathc:  <?php echo $battch?></pre>
				<pre style="color:white;">       Broll:  <?php echo $broll?></pre>
				<pre style="color:red;"> .........</pre>
		
			</div>
			
		</div>
		
	</div>
		
	<div class="col-md-2"></div>

</div>
</div>
 
</body>
</html>
