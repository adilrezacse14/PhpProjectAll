<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>write test for phpexel</title>
</head>
<body>


	<?php
		
		require_once "Classes/PHPExcel.php";
		#creat new object of php exel
		$obj=new PHPExcel;
		#set font
		$obj->getDefaultStyle()->getFont()->setName('cambria');
		$obj->getDefaultStyle()->getFont()->setSize(11);
		#create a objct of php exel writter
		$objwriter=PHPExcel_IOFactory::createWriter($obj, 'Excel2007');
		$worksheet=$obj->getActivesheet();
		$worksheet->setTitle("this is writting");
		$worksheet->getCell('A1')->setValue("Name");
		$worksheet->getCell('B1')->setValue("email");
		
		$worksheet->getCell('A2')->setValue("Adil reza");
		$worksheet->getCell('B2')->setValue("adilreza043@gmail.com");
		
		$objwriter->save('writetest.xlsx');
	
	?>
	
</body>
</html>